# Wishing Well Auto-Player Bot

## How to Install the APK onto Your Android Phone

### OPTION 1: 30-Second Install via Android Studio (Recommended)
1. Download this zip and extract it on your computer.
2. Open **Android Studio** -> click **Open** -> choose this extracted folder.
3. Connect your Android phone with USB (enable **USB Debugging** in phone *Settings -> Developer Options*).
4. Click the green **Run (Shift + F10)** button in Android Studio.
5. Android Studio automatically compiles the APK and installs it straight onto your phone!

Or to generate the standalone **.apk** file:
- Go to menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
- Click "locate" when finished -> Transfer `app-debug.apk` to your phone via WhatsApp, Telegram, or Google Drive, then tap to install!

---

### OPTION 2: Free 1-Click Cloud APK Builder (No Android Studio Needed!)
If you do not have Android Studio installed:
1. Create a free GitHub repository (e.g., github.com/new).
2. Upload this extracted folder to the repository.
3. GitHub Actions will automatically run the included `.github/workflows/build-apk.yml`.
4. Within 2 minutes, click on **Actions** -> click the latest run -> download the **WishingWellAutoPlayer-debug-apk** artifact!
5. Transfer the APK to your phone and install!

---

### Once Installed on Your Phone:
1. Open the app: it will directly guide you to grant **Display over other apps** (for the Floating Controller).
2. It will direct you to **Settings > Accessibility > Downloaded Apps > Wishing Well Auto-Player Bot -> Turn ON**.
3. Open the **Wishing Well** game.
4. Tap **"▶ START BOT"** on the floating overlay button!
