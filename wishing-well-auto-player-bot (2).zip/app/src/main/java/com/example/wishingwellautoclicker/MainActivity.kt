package com.example.wishingwellautoclicker

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity: Direct Gateway (No Home Screen Layout)
 *
 * Bypasses app home screen menus entirely:
 * 1. Verifies SYSTEM_ALERT_WINDOW (Display over other apps) for the Floating Controller.
 * 2. Verifies BIND_ACCESSIBILITY_SERVICE for programmatic touch gestures & screen vision.
 * 3. Immediately directs user to the exact missing permission screen.
 * 4. Once granted, displays a quick confirmation toast and finishes itself so the floating
 *    controller HUD floats immediately on top of the Wishing Well game screen!
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // No setContentView() - intentional design to bypass home screen menus!
    }

    override fun onResume() {
        super.onResume()
        checkPermissionsAndDirectLaunch()
    }

    private fun checkPermissionsAndDirectLaunch() {
        // Step 1: Check Floating Overlay Permission (SYSTEM_ALERT_WINDOW)
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please enable 'Display over other apps' to activate Floating Controller",
                Toast.LENGTH_LONG
            ).show()

            val overlayIntent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(overlayIntent)
            return
        }

        // Step 2: Check Accessibility Service Permission
        val isAccessibilityEnabled = isAccessibilityServiceEnabled(
            this,
            WishingWellAccessibilityService::class.java
        )

        if (!isAccessibilityEnabled) {
            Toast.makeText(
                this,
                "Please turn ON 'WishingWellAccessibilityService' in Accessibility",
                Toast.LENGTH_LONG
            ).show()

            val accessibilityIntent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(accessibilityIntent)
            return
        }

        // Step 3: All permissions active! Launch game or finish to show floating controller
        Toast.makeText(
            this,
            "Auto-Player Active! Floating Controller is ready over your screen.",
            Toast.LENGTH_SHORT
        ).show()

        // Try launching Wishing Well game directly if installed
        val gameLaunchIntent = packageManager.getLaunchIntentForPackage("com.wishingwell.game")
            ?: packageManager.getLaunchIntentForPackage("com.voodoo.wishingwell")
        
        if (gameLaunchIntent != null) {
            startActivity(gameLaunchIntent)
        }

        // Finish activity so it does not linger in the background
        finish()
    }

    private fun isAccessibilityServiceEnabled(context: Context, service: Class<*>): Boolean {
        val expectedComponentName = "${context.packageName}/${service.name}"
        val enabledServicesSetting = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServicesSetting)

        while (colonSplitter.hasNext()) {
            val componentName = colonSplitter.next()
            if (componentName.equals(expectedComponentName, ignoreCase = true)) {
                return true
            }
        }
        return false
    }
}
