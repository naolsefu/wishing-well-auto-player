package com.example.wishingwellautoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

/**
 * WishingWellAccessibilityService
 *
 * FULL AUTONOMOUS SELF-PLAYING BOT with:
 * 1. DRAGGABLE FLOATING CONTROLLER (WindowManager overlay over Wishing Well).
 * 2. REAL-TIME SCREEN VISION LOOP (Pixel scanning above bucket for falling rocks).
 * 3. REACTIVE OBSTACLE DODGING (Instant dispatchGesture evasive shifts).
 * 4. AUTO-UPGRADES & RESULTS NAVIGATION (Automated cycle continuation).
 */
class WishingWellAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "WishingWellBot"

        // =====================================================================
        // COORDINATES & BASE SPECIFICATIONS (720x1568 Base Resolution)
        // Automatically scaled to fit any phone display in onServiceConnected()
        // =====================================================================
        const val BASE_WIDTH = 720f
        const val BASE_HEIGHT = 1568f

        // Menu & Action Coordinates
        const val TAP_TO_DROP_X = 360.0f
        const val TAP_TO_DROP_Y = 710.0f

        const val BUCKET_UPGRADE_X = 200.0f
        const val BUCKET_UPGRADE_Y = 1220.0f

        const val DEPTH_UPGRADE_X = 520.0f
        const val DEPTH_UPGRADE_Y = 1220.0f

        // Results & Popup Dismiss Coordinates
        const val BACK_TO_MENU_X = 360.0f
        const val BACK_TO_MENU_Y = 1120.0f

        const val DISMISS_POPUP_X = 520.0f
        const val DISMISS_POPUP_Y = 700.0f

        // Multi-Lane Steering Coordinates (Strategic Well Shaft Lanes)
        const val LANE_FAR_LEFT = 180.0f
        const val LANE_MID_LEFT = 270.0f
        const val LANE_CENTER = 360.0f
        const val LANE_MID_RIGHT = 450.0f
        const val LANE_FAR_RIGHT = 540.0f

        const val SWEEP_BASE_Y = 1050.0f

        // Screen Vision & Obstacle Scanning Area (Band above bucket)
        const val VISION_SCAN_HEIGHT = 180f   // Height of scan zone in pixels
        const val VISION_OFFSET_ABOVE_BUCKET = 50f // Distance above bucket to inspect
        const val VISION_SCAN_INTERVAL_MS = 150L
        const val OBSTACLE_SENSITIVITY = 3 // Minimum rock pixels to trigger evasion

        // Game Progression Timing
        const val DESCENT_WAIT_MS = 2200L
        const val REELING_DURATION_MS = 9500L
        const val RESULTS_WAIT_MS = 2000L
        const val LOADING_WAIT_MS = 2400L
        const val UPGRADE_EVERY_N_ROUNDS = 2
    }

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning: Boolean = false
    private var roundNumber: Int = 0

    // Display scaling factors
    private var scaleX: Float = 1.0f
    private var scaleY: Float = 1.0f

    // Current virtual bucket position (in unscaled base coordinate space)
    private var currentBucketX: Float = LANE_CENTER

    // Sweeping & Vision state
    private var isSweepingActive: Boolean = false
    private var sweepDirectionRight: Boolean = true
    private var isVisionScanScheduled: Boolean = false
    private var lastEvasionTime: Long = 0L

    // Floating Overlay Window Views
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var btnToggleBot: Button? = null
    private var tvHudStatus: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        calculateDisplayScale()
        Log.i(TAG, "WishingWellBot connected! Scale: ($scaleX, $scaleY). Setting up Floating Controller...")

        // Attach floating controller on top of the game screen
        setupFloatingController()
    }

    private fun calculateDisplayScale() {
        val wm = getSystemService(WINDOW_SERVICE) as? WindowManager
        if (wm != null) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            scaleX = metrics.widthPixels / BASE_WIDTH
            scaleY = metrics.heightPixels / BASE_HEIGHT
            Log.i(TAG, "Device screen: ${metrics.widthPixels}x${metrics.heightPixels}. Scale: ($scaleX, $scaleY)")
        }
    }

    // =========================================================================
    // 1. DRAGGABLE FLOATING CONTROLLER OVERLAY (WINDOW MANAGER)
    // =========================================================================
    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun setupFloatingController() {
        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Cannot draw overlay: SYSTEM_ALERT_WINDOW permission missing.")
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 180
        }

        // Programmatic lightweight HUD container
        val hudLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.parseColor("#E60F172A")) // Slate 900 semi-transparent
            elevation = 16f
        }

        tvHudStatus = TextView(this).apply {
            text = "Wishing Well Bot"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }

        btnToggleBot = Button(this).apply {
            text = "▶ START BOT"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#16A34A")) // Emerald green
            textSize = 12f
            setPadding(24, 8, 24, 8)
        }

        hudLayout.addView(tvHudStatus)
        hudLayout.addView(btnToggleBot)

        // Draggable touch handling: distinguish drag move vs click
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        hudLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(hudLayout, layoutParams)
                    true
                }
                else -> false
            }
        }

        btnToggleBot?.setOnClickListener {
            if (isRunning) {
                stopBot()
            } else {
                startBot()
            }
        }

        floatingView = hudLayout
        try {
            windowManager?.addView(floatingView, layoutParams)
            Log.i(TAG, "Floating Controller overlay attached to screen successfully!")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to attach floating overlay: ${e.message}")
        }
    }

    private fun updateHudState(running: Boolean, status: String) {
        handler.post {
            tvHudStatus?.text = status
            if (running) {
                btnToggleBot?.text = "⏹ STOP BOT"
                btnToggleBot?.setBackgroundColor(Color.parseColor("#DC2626")) // Rose red
            } else {
                btnToggleBot?.text = "▶ START BOT"
                btnToggleBot?.setBackgroundColor(Color.parseColor("#16A34A")) // Emerald green
            }
        }
    }

    // =========================================================================
    // 2. AUTONOMOUS GAME LOOP STATE MACHINE
    // =========================================================================
    fun startBot() {
        if (isRunning) return
        isRunning = true
        roundNumber = 0
        updateHudState(true, "Bot Active: Menu Phase")
        Log.i(TAG, "=== Wishing Well Self-Play Started ===")
        handler.postDelayed({ executeMenuPhase() }, 600L)
    }

    fun stopBot() {
        isRunning = false
        isSweepingActive = false
        isVisionScanScheduled = false
        handler.removeCallbacksAndMessages(null)
        updateHudState(false, "Bot Paused")
        Log.i(TAG, "Wishing Well Bot stopped.")
    }

    private fun executeMenuPhase() {
        if (!isRunning) return
        roundNumber++
        updateHudState(true, "R#$roundNumber: Upgrading & Dropping")
        Log.i(TAG, ">>> Round #$roundNumber Starting on Main Menu <<<")

        // 1. Attempt upgrades every N rounds
        if (roundNumber % UPGRADE_EVERY_N_ROUNDS == 0) {
            tapScaled(BUCKET_UPGRADE_X, BUCKET_UPGRADE_Y, "Upgrade Bucket Space")

            handler.postDelayed({
                tapScaled(DEPTH_UPGRADE_X, DEPTH_UPGRADE_Y, "Upgrade Well Depth")
            }, 350L)

            handler.postDelayed({
                tapScaled(DISMISS_POPUP_X, DISMISS_POPUP_Y, "Dismiss Popup / No Thanks")
            }, 700L)
        }

        // 2. Tap to Drop
        val dropDelay = if (roundNumber % UPGRADE_EVERY_N_ROUNDS == 0) 1100L else 200L
        handler.postDelayed({
            if (!isRunning) return@postDelayed
            tapScaled(TAP_TO_DROP_X, TAP_TO_DROP_Y, "TAP TO DROP")
            currentBucketX = LANE_CENTER

            // 3. Transition to Reeling & Vision Scanning when bucket reaches bottom
            handler.postDelayed({
                startVisionSweepingPhase()
            }, DESCENT_WAIT_MS)
        }, dropDelay)
    }

    // =========================================================================
    // 3. SCREEN VISION LOOP & REACTIVE OBSTACLE DODGING
    // =========================================================================
    /**
     * STAGE 2: Reeling Up with Live Screen Vision & Obstacle Avoidance
     * Continuously captures screen frames, scans pixel arrays above the bucket,
     * and reacts instantly by shifting the bucket away from detected rocks.
     */
    private fun startVisionSweepingPhase() {
        if (!isRunning) return
        updateHudState(true, "R#$roundNumber: Vision Dodging Active")
        Log.i(TAG, "Bucket reached bottom. Starting Screen Vision Loop...")
        isSweepingActive = true
        isVisionScanScheduled = true

        val startTime = System.currentTimeMillis()

        // 1. Start Background Vision Scanner (runs every VISION_SCAN_INTERVAL_MS)
        scheduleScreenVisionScan()

        // 2. Routine Sweeping Loop (keeps bucket gathering items while dodging)
        val routineSweepRunnable = object : Runnable {
            override fun run() {
                if (!isRunning || !isSweepingActive) return

                val elapsed = System.currentTimeMillis() - startTime
                if (elapsed >= REELING_DURATION_MS) {
                    isSweepingActive = false
                    isVisionScanScheduled = false
                    Log.i(TAG, "Reeling phase complete. Waiting for results...")
                    handler.postDelayed({ executeResultsPhase() }, RESULTS_WAIT_MS)
                    return
                }

                // If no urgent obstacle was just dodged in the last 400ms, perform a collection stroke
                if (System.currentTimeMillis() - lastEvasionTime > 400L) {
                    val targetX = if (sweepDirectionRight) LANE_FAR_RIGHT else LANE_FAR_LEFT
                    sweepDirectionRight = !sweepDirectionRight

                    dispatchCurvedDragScaled(currentBucketX, targetX, SWEEP_BASE_Y, -40f, 600L)
                    currentBucketX = targetX
                }

                handler.postDelayed(this, 750L)
            }
        }

        handler.post(routineSweepRunnable)
    }

    /**
     * Screen Vision Scanner: Captures display frames using AccessibilityService.takeScreenshot()
     * and inspects RGB pixel arrays above the current bucket position for rock obstacles.
     */
    private fun scheduleScreenVisionScan() {
        if (!isRunning || !isVisionScanScheduled || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return
        }

        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshotResult: ScreenshotResult) {
                    val hardwareBuffer = screenshotResult.hardwareBuffer
                    val bitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, screenshotResult.colorSpace)

                    if (bitmap != null) {
                        // Create a software copy to safely read pixel array
                        val softwareBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                        hardwareBuffer.close()

                        if (softwareBitmap != null) {
                            scanPixelsForObstacles(softwareBitmap)
                            softwareBitmap.recycle()
                        }
                    } else {
                        hardwareBuffer.close()
                    }

                    // Reschedule next vision scan
                    if (isRunning && isVisionScanScheduled) {
                        handler.postDelayed({ scheduleScreenVisionScan() }, VISION_SCAN_INTERVAL_MS)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    Log.w(TAG, "takeScreenshot failed with error code: $errorCode")
                    if (isRunning && isVisionScanScheduled) {
                        handler.postDelayed({ scheduleScreenVisionScan() }, VISION_SCAN_INTERVAL_MS * 2)
                    }
                }
            }
        )
    }

    /**
     * SCREEN VISION ANALYSIS:
     * 1. Scans for rock/obstacle pixels directly above the bucket coordinates.
     * 2. Scans adjacent lanes for gold coins, gems, and crowns to actively steer toward loot.
     * 3. Dispatches immediate evasive swipes when obstacles threaten the bucket.
     */
    private fun scanPixelsForObstacles(frameBitmap: Bitmap) {
        val currentXScaled = (currentBucketX * scaleX).toInt().coerceIn(0, frameBitmap.width - 1)
        val scanStartY = ((SWEEP_BASE_Y - VISION_SCAN_HEIGHT) * scaleY).toInt().coerceIn(0, frameBitmap.height - 1)
        val scanEndY = ((SWEEP_BASE_Y - VISION_OFFSET_ABOVE_BUCKET) * scaleY).toInt().coerceIn(0, frameBitmap.height - 1)

        var rockPixelCount = 0
        val sampleStep = 5 // Sample step in pixels for ultra-fast frame processing

        // A. Scan the critical danger column directly above the bucket
        for (y in scanStartY..scanEndY step sampleStep) {
            for (dx in -20..20 step 8) {
                val x = (currentXScaled + dx).coerceIn(0, frameBitmap.width - 1)
                val pixelColor = frameBitmap.getPixel(x, y)

                if (isRockObstacleColor(pixelColor)) {
                    rockPixelCount++
                }
            }
        }

        // B. Reactive Dodging: Rock detected in current lane!
        if (rockPixelCount >= OBSTACLE_SENSITIVITY) {
            Log.w(TAG, "🚨 [SCREEN VISION] Rock detected in bucket lane (X=$currentBucketX, rockPixels=$rockPixelCount)!")
            executeEmergencyObstacleDodge(frameBitmap)
        } else {
            // C. Opportunistic Steering: Current lane is safe, check for nearby gold/coins/gems!
            steerTowardNearestTreasure(frameBitmap, scanStartY, scanEndY)
        }
    }

    /**
     * Checks if a screen pixel matches gold coins or active upgrade buttons:
     * High red and green components with low blue (Golden Amber / Canary Yellow).
     */
    fun isGoldCoinOrUpgradeColor(color: Int): Boolean {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)

        // Gold coin & active upgrade button signature
        val isYellowGold = r in 190..255 && g in 135..230 && b in 0..85
        val hasGoldRatio = (r.toFloat() / maxOf(1, b)) > 2.4f && (g.toFloat() / maxOf(1, b)) > 1.8f

        return isYellowGold && hasGoldRatio
    }

    /**
     * Checks if a screen pixel matches rocks or obstacles:
     * Neutral grey / dark brown stone texture with low color saturation.
     */
    fun isRockObstacleColor(color: Int): Boolean {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)

        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val saturation = if (max == 0) 0f else (max - min).toFloat() / max

        // Grey/brown stone texture signature (or red collision impact particles)
        val isGreyStone = max in 50..140 && saturation < 0.22f
        val isDarkRock = max in 35..85 && saturation < 0.35f
        val isImpactRed = r > 180 && g < 70 && b < 70

        return isGreyStone || isDarkRock || isImpactRed
    }

    /**
     * Checks if a pixel matches valuable loot (Gold bags, crowns, rubies, diamonds, pearls).
     */
    fun isTreasureColor(color: Int): Boolean {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)

        val isGold = isGoldCoinOrUpgradeColor(color)
        val isRuby = r > 180 && g < 65 && b < 65
        val isDiamond = b > 190 && g > 150 && r < 120
        val isPearl = r > 215 && g > 215 && b > 215

        return isGold || isRuby || isDiamond || isPearl
    }

    /**
     * Scans an upgrade button area on the main menu to confirm if it has golden active pixels
     * (meaning the player has earned enough coins to afford the upgrade).
     */
    fun isUpgradeButtonAffordable(frameBitmap: Bitmap, centerX: Float, centerY: Float): Boolean {
        val xScaled = (centerX * scaleX).toInt().coerceIn(0, frameBitmap.width - 1)
        val yScaled = (centerY * scaleY).toInt().coerceIn(0, frameBitmap.height - 1)

        var goldPixels = 0
        for (dy in -15..15 step 4) {
            for (dx in -30..30 step 6) {
                val x = (xScaled + dx).coerceIn(0, frameBitmap.width - 1)
                val y = (yScaled + dy).coerceIn(0, frameBitmap.height - 1)
                if (isGoldCoinOrUpgradeColor(frameBitmap.getPixel(x, y))) {
                    goldPixels++
                }
            }
        }
        return goldPixels >= 6
    }

    /**
     * When current lane is clear of rocks, inspects Left and Right lanes for gems/coins
     * and shifts toward the richest treasure cluster.
     */
    private fun steerTowardNearestTreasure(frameBitmap: Bitmap, scanStartY: Int, scanEndY: Int) {
        val now = System.currentTimeMillis()
        if (now - lastEvasionTime < 450L) return

        val lanes = listOf(LANE_FAR_LEFT, LANE_MID_LEFT, LANE_CENTER, LANE_MID_RIGHT, LANE_FAR_RIGHT)
        var bestLane = currentBucketX
        var maxTreasure = 0

        for (laneX in lanes) {
            val laneXScaled = (laneX * scaleX).toInt().coerceIn(0, frameBitmap.width - 1)
            var laneRocks = 0
            var laneTreasures = 0

            for (y in scanStartY..scanEndY step 8) {
                val color = frameBitmap.getPixel(laneXScaled, y)
                if (isRockObstacleColor(color)) laneRocks++
                if (isTreasureColor(color)) laneTreasures++
            }

            // Only consider lane if zero rocks are present
            if (laneRocks == 0 && laneTreasures > maxTreasure) {
                maxTreasure = laneTreasures
                bestLane = laneX
            }
        }

        if (bestLane != currentBucketX && maxTreasure >= 2) {
            Log.d(TAG, "✨ [LOOT STEERING] Detected $maxTreasure treasures in lane $bestLane! Steering bucket...")
            dispatchLinearDragScaled(currentBucketX, bestLane, SWEEP_BASE_Y, 280L)
            currentBucketX = bestLane
            lastEvasionTime = now
        }
    }

    /**
     * Emergency Dodge: Picks the adjacent clear lane with lowest rock density.
     */
    private fun executeEmergencyObstacleDodge(frameBitmap: Bitmap) {
        val now = System.currentTimeMillis()
        if (now - lastEvasionTime < 250L) return // Debounce rapid evasions
        lastEvasionTime = now

        val leftCandidate = (currentBucketX - 160f).coerceAtLeast(LANE_FAR_LEFT)
        val rightCandidate = (currentBucketX + 160f).coerceAtMost(LANE_FAR_RIGHT)

        val evasionTargetX = if (currentBucketX > LANE_CENTER) {
            leftCandidate
        } else {
            rightCandidate
        }

        Log.i(TAG, "⚡ [DODGE ACTION] Shifting bucket from $currentBucketX -> $evasionTargetX via emergency swipe!")
        dispatchLinearDragScaled(currentBucketX, evasionTargetX, SWEEP_BASE_Y, 200L)
        currentBucketX = evasionTargetX
    }

    // =========================================================================
    // 4. RESULTS & NAVIGATION
    // =========================================================================
    private fun executeResultsPhase() {
        if (!isRunning) return
        updateHudState(true, "R#$roundNumber: Collecting Earnings")
        Log.i(TAG, "Tapping 'BACK TO MENU' button...")

        tapScaled(BACK_TO_MENU_X, BACK_TO_MENU_Y, "BACK TO MENU")

        handler.postDelayed({
            tapScaled(BACK_TO_MENU_X, BACK_TO_MENU_Y, "BACK TO MENU (confirm)")
        }, 400L)

        handler.postDelayed({
            if (isRunning) {
                executeMenuPhase()
            }
        }, LOADING_WAIT_MS)
    }

    // =========================================================================
    // 5. GESTURE DISPATCH HELPERS
    // =========================================================================
    fun dispatchCurvedDragScaled(startX: Float, endX: Float, y: Float, arcOffsetY: Float, durationMs: Long) {
        val sX = startX * scaleX
        val eX = endX * scaleX
        val sY = y * scaleY
        val midX = (sX + eX) / 2f
        val controlY = (y + arcOffsetY) * scaleY

        val curvedPath = Path().apply {
            moveTo(sX, sY)
            quadTo(midX, controlY, eX, sY)
        }

        val stroke = GestureDescription.StrokeDescription(curvedPath, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    fun dispatchLinearDragScaled(startX: Float, endX: Float, y: Float, durationMs: Long) {
        val sX = startX * scaleX
        val eX = endX * scaleX
        val sY = y * scaleY

        val linearPath = Path().apply {
            moveTo(sX, sY)
            lineTo(eX, sY)
        }

        val stroke = GestureDescription.StrokeDescription(linearPath, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    fun tapScaled(x: Float, y: Float, label: String) {
        val targetX = x * scaleX
        val targetY = y * scaleY

        val clickPath = Path().apply { moveTo(targetX, targetY) }
        val stroke = GestureDescription.StrokeDescription(clickPath, 0L, 80L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { stopBot() }

    override fun onDestroy() {
        super.onDestroy()
        stopBot()
        // Clean up floating WindowManager view
        if (floatingView != null && windowManager != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing floating view: ${e.message}")
            }
        }
    }
}
